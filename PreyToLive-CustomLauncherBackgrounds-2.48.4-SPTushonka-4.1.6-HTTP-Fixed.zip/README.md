﻿# **PreyToLive-CustomLauncherBackgrounds v2.5.0** (SPT 5.0 / SPTushonka)

Developed by: [NEWBR33D](https://github.com/NEWBR33D) (aka [PreyToLive](https://hub.sp-tarkov.com/user/24548-preytolive/))

Originally a mod for SPT-AKI 3.8 - SPT 3.10; this version is a full port of
[CustomLauncherBackgrounds](https://github.com/NEWBR33D/CustomLauncherBackgrounds) to
**SPT 5.0 (SPTushonka)**, rebuilt against the new C# server mod system.

With this mod, a random image from a designated folder is selected each time you restart the server
and applied to the launcher background.

#### ***If you would like to support me and my work you can donate to me [here](https://ko-fi.com/preytolive). Thank you!***

---

## **How it works on SPT 5.0**

The SPT 5.0 launcher has its background baked into the launcher itself and no longer downloads it from the
server (its settings say *"Image cannot be changed for now"*). This mod therefore:

* **writes the chosen image directly into the launcher** on every server start
  (`SPT.Launcher.exe` and `SPT.Launcher.Linux`) - the launcher shows the new background the next time it starts,
* keeps serving the image at the classic route `/files/launcher/bg` (used by 4.0.x launchers,
  remote setups and other tools), and
* adds a **preview page** to the server's web interface (the "Server Information Center") showing the
  current background, the active folder and the launcher patch status. The page is reachable from the
  launcher's Mod Pages panel and the tray menu ("Server Information Center").

### **Good to know**

* The first time a background is applied, a **one-time backup** of each launcher file
  (`SPT.Launcher.exe.original`, `SPT.Launcher.Linux.original`) is created next to it.
* The **launcher must be closed while the server starts** for the image to be written - a running
  launcher locks its own executable. If you see "could not write" on the web page, close the launcher
  and restart the server once.
* **SPT updates replace the launcher** - just start the server once afterwards and the background is
  re-applied automatically.
* Images larger than the launcher's built-in background slot (~130 KB) are automatically
  re-encoded/downscaled to fit (`.jpg`, `.png`, `.jpeg`, `.webp` and other common formats).
* Prefer the classic route only? Set `"patchLauncher": false` in the config to disable writing to
  the launcher.

### **Players on other computers (remote servers)**

When players connect to your server from another computer, their launcher is a local file that this server
cannot change directly. For those players the mod page (in the server's web interface, linked from the
launcher's Mod Pages panel) offers a small download:

* Download the `LauncherPatcher` tool (Windows `.exe` / Linux binary, `patch-and-launch.cmd` and a readme)
  from the "Players on other computers" section of the mod page.
* Extract the `LauncherPatcher` folder into `SPT_Runtime` (next to `SPT.Launcher.exe`), close the launcher
  and run `patch-and-launch.cmd` - or the patcher directly. It downloads the current background from your
  server and applies it to the local launcher (byte-identical to a local server install).
* It uses the server from the player's launcher settings automatically; `--server https://host:6969`
  overrides it. Players simply run it again whenever they want to pick up the latest background.
* **Even easier for players: the optional in-game prompt.** Players who install the small
  `CustomLauncherBackgrounds.Gui` client plugin (downloadable from the mod page, or included in your client
  pack under `BepInEx\plugins\`) get a window in-game asking whether they want to update their launcher to
  this server's background. Accepting downloads a ready-patched `SPT.Launcher.exe` from this server, closes
  the SPT launcher (if it is still running - it usually sits in the tray and locks its own file) and then
  **closes the game** - the launcher is patched right after the game has exited (see below). The window is
  a large centered light grey panel showing **Custom Launcher Backgrounds** and **Launcher is outdated**
  (both bold + highlighted), the line `The server has updated it's launcher since your last session.` and
  the buttons **Update / Skip / Never**; after a player updates (or chooses "Never") they are only asked again
  when the server's launcher build changes - a mod update, an SPT update, or changed rotation settings
  (the mod page shows the current build id).

### **Corter-ModSync servers: automatic distribution**

If your server uses [Corter-ModSync](https://github.com/Dildz/ModSync-for-SPT4), the mod registers the
patched launcher as a served path there automatically (once, on the next server start after installing this
mod). From then on every player receives the current launcher through their normal ModSync sync:

* ModSync applies `restartRequired` files only **after the game exits** (its `ModSync.Updater.exe`) or at
the next game start (its prepatcher). Note: if the SPT launcher is still running when the game exits, it
locks its own file - ModSync then applies the update at the next game start instead. The optional in-game
plugin removes that delay by closing the launcher before the update runs.
* Players see the update as the "SPT Launcher (custom background)" entry in their F12 sync menu and can
tick it off - a `.modsync-bak` restore file (created by the in-game plugin) brings their original launcher
back if they do.
* No client plugin is required for this channel; the in-game prompt (above) simply stages its downloads
through the same ModSync pipeline when ModSync is present.
* Set `"modSyncIntegration": false` in the mod's `config.json` (or delete the entry from
  `user/mods/Corter-ModSync/config.jsonc`) to manage the launcher yourself. A one-time backup of the edited
  config is kept as `config.jsonc.clb-backup`.

### **Managing backgrounds & settings in the browser**

The mod page on the SPT server's web UI ("Custom Launcher Backgrounds") is a full editor:

* **Images & videos** - see everything in `res/Images` / `res/Videos` (type, size, pixels), delete files,
  and upload new ones with the built-in **image/video formatter**: images are converted to PNG or JPEG and
  resized/cropped to 900x450, 1920x1080 or kept at their original size; mp4 videos are checked and stored.
  Uploads are numbered automatically ("(n)-bg.png"), so they slot into the ordered rotation, and every
  change is applied immediately (no server restart).
* **Settings** - enable/disable the mod, launcher patching, Corter-ModSync integration and console logs,
  set the rotation interval/port, choose the folder and bind the rotation server - with "Save & apply".

### **Background rotation**

Instead of one fixed background per server start, the launcher rotates through the playlist while it is open.
By default that playlist is `res/Images` (numbered `1-bg.png` ... up to `100-bg.png`, rotating **in order**
from a random starting point each server start) plus `res/Videos` for `.mp4` clips (played muted and looping).
Images (`.jpg`, `.jpeg`, `.png`, `.webp`, `.bmp`) and videos can be mixed, and backgrounds **crossfade**
when they switch for a smooth look:

* On every server start the mod also patches the launcher's own web page so its background polls a tiny
  plain-HTTP rotation server that this mod runs (the launcher page is served over `http://localhost`, so this
  needs no certificates and no browser setup).
* `"rotationSeconds"` sets how often the image changes - default `60`, `0` disables rotation and keeps
  the static per-start background. The patched launcher polls a tiny state endpoint every 10 seconds and
  only reloads when the background actually changed, so a change shows up within seconds at any interval.
* `"useImages"` and `"useVideos"` (both default true) choose what rotates: images only, videos only, or -
  with both on - a slideshow that **alternates image, video, image...** (the shorter list wraps).
  In the web editor each has its own section (toggle, files, upload) under **Images** and **Videos**.
* Uploads are named automatically **per kind**: the first image becomes `res/Images/1-bg.png` (then
  `2-bg.png`, ...) and the first video `res/Videos/1-bg.mp4` (then `2-bg.mp4`, ...), so both lists start at
  `1-bg` and new files slot straight into the ordered rotation.
* A small **mute icon** sits in the launcher's left rail just above the Settings gear - clear on the
  background like the other rail icons (speaker, with a slash while muted; the choice is remembered). Audio
  also mutes automatically while the window is minimized. The launcher's own **Settings -> Interface**
* Every **Save & apply** (or the apply button) in the web editor advances the published launcher build, so
  players are prompted in-game to refresh their launcher - server restarts alone do not (no prompt spam).
  Players who chose "Never" stay suppressed.
  section gains a **Volume** slider for the video soundtrack (remembered per machine).
* Images and videos rotate on **separate intervals** (`imageRotationSeconds` / `videoRotationSeconds` in
  config.json or the editor) - e.g. images every 10 s, videos every 60 s.
* The launcher Info page supports multiple text boxes (one launcher card each; add/remove them in the web
  app) and every box opens the custom link you set.
* The launcher Info page text can open a custom link on click (set it in the web app; replaces the stock
  sp-mod.com link, empty = inert).
* The launcher Info page can be replaced with your own text (multiline, edited in the web app; text edits
  need no launcher re-patch).
* Panel opacity applies to the launcher cards, dialogs, **tab panels (e.g. the character stats screen)**, **mod-pages panels and SIC panels** (nested SIC
elements stay clear so the tint never stacks).
* The in-game update prompt uses a dark rounded card with a blue primary action (matching the mod site's
  card style); quoted lines are bold with a soft blue highlight.
* Every transition blends: still->still dissolves through the launcher's base layer (1 s), still<->video
  crossfades the canvas against the video layers, and video->video crossfades two video layers.
* Still backgrounds are drawn through a canvas rather than an `<img>`: Chromium dithers large image layers
  (a faint dot pattern on dark, flat areas) and the canvas path is perfectly clean.
* Image format is auto-detected from the file's **bytes** (not its name): JPEG sources stay JPEG, everything
  else is stored as PNG - downloads saved with a wrong extension are handled correctly. Explicit PNG/JPEG
  choices in the upload form override this.
* **JPEG cleanup** (Off / Light / Strong / **Maximum** - the last one also smooths grain) deblocks imported images: wallpapers saved from the web carry an
  8x8 JPEG block grid that shows up as a dot pattern once the launcher scales them down; this levels those
  boundaries without softening texture or shifting colours.
* Images are resized with an explicit trade-off: **Crop to fill** (full-bleed, cuts the overflow) or
  **Fit - blurred background** (nothing is cut; the leftover space is filled with a blurred copy of the
  image). Defaults: 1920x1080 (16:9, matching the launcher window), **Stretch to size** and PNG.
* The web editor lets you **select several images/videos at once** (checkboxes + select-all) and delete
  them in one go (the numbering gaps close once).
* Videos play with **sound** in the launcher (unmuted as soon as playback starts) and are paused and muted
the moment a still image takes over (no leftover audio); they also mute automatically
  while the launcher window is minimized. Switching between videos crossfades just like images do.
* `"launcherBackgroundVeilPercent"` (a field on the mod page, under Panel opacity) sets the strength of
  the launcher's **dark veil over the background image/video**: 100 = stock veil, 0 = the artwork
  shows fully clear, in between scales it. Baked in when the launcher is patched, so close the
  launcher and Save & apply.
* `"hideLocalServerCard"` (a switch on the mod page) hides the launcher's **Local Server** entry
  (`127.0.0.1`) from its server list - the freed slot is reused by the next server you add. Baked in when
  the launcher is patched, so close the launcher and Save & apply. Switch it off to bring the card back.
* Deleting a file **closes the numbering gap**: with `1-bg`-`2-bg`-`3-bg`, deleting `2-bg` renames `3-bg`
  to `2-bg` (and everything after it down by one) on the next apply - so the sequence always stays
  contiguous. Files that do not follow the `(n)-bg` naming are never touched.
* Uploads are de-duplicated by content: if the file (after formatting) is byte-identical to something
  already in that folder, it is **not stored again** - the upload reports `identical to 1-bg.png - not
  added` and no number is used up.
* Re-uploading a file with the **same name** (e.g. an updated `killa.png`) replaces its stored copy in
  place - `5-bg.png` keeps its number and gets the new picture, and the recorded hash is refreshed so the
  new version is not added again on a later upload either.
* Images always rotate in **number order** (`1-bg`, `2-bg`, ...); by default the slideshow starts on a
  random one each server start. Set `"randomRotationStart": false` (mod page: *Random start point*) to
  always begin at `1-bg` and play through in order.
* Video uploads are accepted up to **2 GB** (images 512 MB). Uploads stream straight to disk on the server
  and the rotation server streams clips from disk, so large videos do not use up the server's memory.
* ffmpeg for video formatting is found automatically: drop `ffmpeg.exe` into the mod folder (best:
  `ffmpeg\ffmpeg.exe` next to the mod dll; also `ffmpeg.exe` in the mod root, `ffmpeg\bin\ffmpeg.exe` or
  `tools\ffmpeg\...`), or set `"videoFfmpegPath"` (absolute, or relative to the mod folder), or have it on
  the PATH / at `C:\ffmpeg`. Only `ffmpeg.exe` is needed - no ffprobe.
* Uploaded videos can be **formatted** like images (target size + fit): set `"videoFfmpegPath"` to an ffmpeg
  executable (or leave blank to auto-detect on the PATH / `C:\ffmpeg`) and the server re-encodes clips to
  the chosen size (H.264 mp4). Without ffmpeg available, clips are stored unchanged (with a note).
* `"rotationHttpPort"` is the rotation server port (default `6970`). By default it binds loopback only; set
  `"rotationHttpIP"` to your LAN/VPN/public address (or `"0.0.0.0"` for all interfaces) so launchers on
  other computers can rotate too - loopback stays bound for this machine, and downloaded launchers get
  that address baked in. `"rotationBindAll"` is the simpler "bind every interface" equivalent.
* With `"consoleLogs": true` the server logs every rotation step
  (`background rotation -> 12-bg.png (12/35)`) - the switch is also on the mod page; with the default
  `false` only the startup line and any errors appear.
* `"rotationHttpPort"` (default `6970`) is the port the rotation server listens on.
* For launchers on **other computers**: set `"rotationBindAll": true` (opens the port to your LAN/internet)
  and configure your backend ip - downloaded launchers then poll `http://<backend-ip>:<port>/bg.jpg`.
  Players who never received a patched launcher simply keep the static background.
* If the rotation server is unreachable (or the server is stopped), the launcher quietly keeps showing the
  last background and picks rotation back up once it is reachable again.
* While patching, the launcher chrome is cleaned up: the backdrop blur in front of the artwork is removed
  (its dark tint stays), the left nav rail loses its panel border/shadow (icons stay) and the top bar's
  button loses its dark fill/border - so the artwork covers the whole window. The (unrelated) dialog
  backdrop blur is left alone.
* Frosted panels (server/profile cards, dialogs, tabs, popovers) default to 45% instead of the launcher's
  stock 70%, so the artwork shows through them more (the frosted blur stays, text stays readable). The
  value is configurable: `"launcherPanelOpacityPercent"` (0 = completely clear cards - no tint and no
  frosting; 70+ = the launcher's stock frosted look; 100 = solid), also a field on the mod page. The
  frosting blur scales with the value. It is baked into the launcher when it is (re-)patched, so change it
  with the launcher closed.
* The launcher window keeps its normal title bar, but its **border follows the Panel opacity setting**: below
  70 (panels cleared away from the stock frosted look) it is tinted with the launcher's own light line shade
  so it blends, while 70+ leaves the stock border alone. A fully
  **borderless** window (no title bar at all) is available too (`"launcherWindowBorderless"`, default off):
  move it with Win+Arrow/Alt+Space, close with Alt+F4. The server applies the chrome to the host's launcher
  while it runs; the in-game plugin does the same on players' machines, and turning borderless off restores
  the title bar automatically.
* Videos are fetched whole on each rotation - keep them reasonably sized (a few MB, H.264 mp4) and prefer a
  longer `rotationSeconds` for video-heavy folders. The launcher's embedded fallback image (used before the
  first rotation and while no server is reachable) always comes from a still image; with a video-only folder
  it simply keeps its previous still.

## **Installation Instructions:**

1. Download `PreyToLive-CustomLauncherBackgrounds-2.5.1-SPTushonka-5.0.zip`.
2. Extract the contents with 7-Zip - you will get a `SPT_Runtime` folder.
3. Drag the `SPT_Runtime` folder into your SPT install folder (where `SPT_Runtime` already lives) and merge/overwrite.
4. If you used the old SPT 3.x version of this mod, delete the old `user/mods/zPreyToLive-CustomLauncherBackgrounds` folder first
   (the old JavaScript version cannot run on SPT 5.0).
5. Start the server, then start the launcher. A random background is picked on every server start.

The mod lives at `SPT_Runtime/user/mods/PreyToLive-CustomLauncherBackgrounds/`.

## **Setup Guide:**

1. Open the `config.json` in the mod's folder (or use the server's web config editor).
2. The default backgrounds (the 35 artworks) live in `res/Images`, numbered `1-bg.png` ... `35-bg.png`;
   videos go into `res/Videos`. This is the default playlist, so `launcherFolderToUse` stays empty.
   The playlist rotates **in order** (starting at a random number each server start), supports up to 100
   numbered images (more works too) and crossfades on every switch.
3. Prefer your own set? Create a subfolder such as `res/mySet` (the older `res/launchers/mySet` layout
   keeps working too) and set `launcherFolderToUse` to its name:
```
    "modEnabled": true,
    "consoleLogs": false,
    "launcherFolderToUse": "",     // empty = the res folder itself; or a subfolder name like "mySet"
    "patchLauncher": true,
    "rotationSeconds": 60,       // background rotation interval (0 = static background per server start)
    "rotationHttpPort": 6970,    // local port the launcher polls for rotated images
    "rotationBindAll": false,    // true = also serve rotation to launchers on other computers
```
4. To use your own backgrounds, add your images (`.jpg`, `.jpeg`, `.png`, `.webp`, `.bmp`) and/or videos
   (`.mp4`) to a subfolder like `res/mySet` and set `launcherFolderToUse` accordingly - or replace the
   numbered files in `res/Images` (keeping the `(number)-bg.png` names gives you ordered rotation).
5. Restart the server after changing the config (with the launcher closed) to apply the new background.

## **Disclaimer:**
I do not claim ownership of any rights to the images or artwork utilized within this mod. The launcher background
artwork found in the mod's `res/Images` folder is created by [Vlad Novikov](https://www.artstation.com/yu2673)
and [Eugene Shushliamin](https://www.artstation.com/geck).

Licensed under the MIT License - see `LICENSE.md`. Bundled runtime libraries (System.Drawing.Common and its
dependencies) are MIT-licensed components from the .NET runtime.
